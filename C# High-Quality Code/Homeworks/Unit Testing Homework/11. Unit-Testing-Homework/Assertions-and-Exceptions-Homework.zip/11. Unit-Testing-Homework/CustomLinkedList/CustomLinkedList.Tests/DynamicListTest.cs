﻿namespace CustomLinkedList.Tests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class DynamicListTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void DynamicListSetter_TestWithInvalidIndex_ShouldTrowArgumentOutOfRangeException()
        {
            var testList = new DynamicList<int>();

            var indexGreater = testList.Count + 3;
            var indexLower = -2;

            Assert.IsNull(
                testList[indexGreater], 
                "Number of dynamic list positions cannot be more than its count.");

            Assert.IsNull(
                testList[indexLower],
                "Number of dynamic list positions cannot be < 0");
        }

        [TestMethod]
        public void Add_NonEmpty_HasContaintAfter()
        {
            var testList = new DynamicList<string>();

            string person1 = "Alex";
            testList.Add(person1);

            Assert.IsTrue(testList.Count == 1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void RemoveAt_TestWithInvalidIndex_ShouldTrowArgumentOutOfRangeException()
        {
            
        }


    }
}
